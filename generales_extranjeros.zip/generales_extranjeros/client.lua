RegisterCommand("generales",function()
    msg("¡Bienvenido Extranjero!")
    msg("Las normas más importantes son las siguientes:")
    msg("MetaGaming: No podrás utilizar información ooc para beneficiar a tu personaje")
    msg("PowerGaming: No podrás hacer ningún acto IC que te resultaria imposible hacerla OOC")
    msg("RevangeKill: Ocurre cuando tu personaje se muere, y es reanimado por un médico. Al despertar, tendrás que simular un estado de animo bajo y no podras recordar nada de lo sucedido en el rol anterior")
    msg("IC: Todo lo que ocurre en la vida de tu personaje.")
    msg("OOC: Es aquello que ocurre cuando hablas o realizas cosas fuera del juego")
    msg("Si incumples algunas de estas normas, podrias ser sancionado!")
end)    

function msg(text)
    TriggerEvent("chatMessage","Alcalde",{0,255,0},text)
end